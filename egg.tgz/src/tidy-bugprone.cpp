// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("tidy bugprone\n", stdout);
  return lionss_run_workload("tidy-bugprone");
}
