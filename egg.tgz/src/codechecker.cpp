// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("codechecker\n", stdout);
  return lionss_run_workload("codechecker");
}
