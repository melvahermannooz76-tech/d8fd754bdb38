// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("microbench"); }
int main(){
  announce();
  return lionss_run_workload("microbench");
}
