// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("ilp32 build\n", stdout);
  return lionss_run_workload("ilp32-build");
}
