// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("mutmut run"); }
int main(){
  announce();
  return lionss_run_workload("mutmut-run");
}
