// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("leak sanitizer\n", stdout);
  return lionss_run_workload("leak-sanitizer");
}
