# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(codechecker src/codechecker.cpp)
set_property(TARGET codechecker PROPERTY CXX_STANDARD 11)
target_link_libraries(codechecker lionss pthread)

add_executable(pch-build src/pch-build.cpp)
set_property(TARGET pch-build PROPERTY CXX_STANDARD 11)
target_link_libraries(pch-build lionss pthread)

add_executable(soname-check src/soname-check.cpp)
set_property(TARGET soname-check PROPERTY CXX_STANDARD 11)
target_link_libraries(soname-check lionss pthread)

add_executable(tidy-modernize src/tidy-modernize.cpp)
set_property(TARGET tidy-modernize PROPERTY CXX_STANDARD 11)
target_link_libraries(tidy-modernize lionss pthread)

add_executable(scan-build src/scan-build.cpp)
set_property(TARGET scan-build PROPERTY CXX_STANDARD 11)
target_link_libraries(scan-build lionss pthread)

add_executable(unreachable-code src/unreachable-code.cpp)
set_property(TARGET unreachable-code PROPERTY CXX_STANDARD 11)
target_link_libraries(unreachable-code lionss pthread)

add_executable(build-minsizerel src/build-minsizerel.cpp)
set_property(TARGET build-minsizerel PROPERTY CXX_STANDARD 11)
target_link_libraries(build-minsizerel lionss pthread)

add_executable(wasi-build src/wasi-build.cpp)
set_property(TARGET wasi-build PROPERTY CXX_STANDARD 11)
target_link_libraries(wasi-build lionss pthread)

add_executable(jumbo-build src/jumbo-build.cpp)
set_property(TARGET jumbo-build PROPERTY CXX_STANDARD 11)
target_link_libraries(jumbo-build lionss pthread)

add_executable(spellcheck src/spellcheck.cpp)
set_property(TARGET spellcheck PROPERTY CXX_STANDARD 11)
target_link_libraries(spellcheck lionss pthread)

add_executable(snapshot-tests src/snapshot-tests.cpp)
set_property(TARGET snapshot-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(snapshot-tests lionss pthread)

add_executable(clang-17 src/clang-17.cpp)
set_property(TARGET clang-17 PROPERTY CXX_STANDARD 11)
target_link_libraries(clang-17 lionss pthread)

add_executable(leak-sanitizer src/leak-sanitizer.cpp)
set_property(TARGET leak-sanitizer PROPERTY CXX_STANDARD 11)
target_link_libraries(leak-sanitizer lionss pthread)

add_executable(gcov-report src/gcov-report.cpp)
set_property(TARGET gcov-report PROPERTY CXX_STANDARD 11)
target_link_libraries(gcov-report lionss pthread)

add_executable(build-pic src/build-pic.cpp)
set_property(TARGET build-pic PROPERTY CXX_STANDARD 11)
target_link_libraries(build-pic lionss pthread)

add_executable(package-flatpak src/package-flatpak.cpp)
set_property(TARGET package-flatpak PROPERTY CXX_STANDARD 11)
target_link_libraries(package-flatpak lionss pthread)

add_executable(linux-armhf src/linux-armhf.cpp)
set_property(TARGET linux-armhf PROPERTY CXX_STANDARD 11)
target_link_libraries(linux-armhf lionss pthread)

add_executable(deprecations-check src/deprecations-check.cpp)
set_property(TARGET deprecations-check PROPERTY CXX_STANDARD 11)
target_link_libraries(deprecations-check lionss pthread)

add_executable(ilp32-build src/ilp32-build.cpp)
set_property(TARGET ilp32-build PROPERTY CXX_STANDARD 11)
target_link_libraries(ilp32-build lionss pthread)

add_executable(unit-tests src/unit-tests.cpp)
set_property(TARGET unit-tests PROPERTY CXX_STANDARD 11)
target_link_libraries(unit-tests lionss pthread)

add_executable(wasm32-build src/wasm32-build.cpp)
set_property(TARGET wasm32-build PROPERTY CXX_STANDARD 11)
target_link_libraries(wasm32-build lionss pthread)

add_executable(hermetic-build src/hermetic-build.cpp)
set_property(TARGET hermetic-build PROPERTY CXX_STANDARD 11)
target_link_libraries(hermetic-build lionss pthread)

add_executable(valgrind-cachegrind src/valgrind-cachegrind.cpp)
set_property(TARGET valgrind-cachegrind PROPERTY CXX_STANDARD 11)
target_link_libraries(valgrind-cachegrind lionss pthread)

add_executable(mutmut-run src/mutmut-run.cpp)
set_property(TARGET mutmut-run PROPERTY CXX_STANDARD 11)
target_link_libraries(mutmut-run lionss pthread)

add_executable(vectorization-report src/vectorization-report.cpp)
set_property(TARGET vectorization-report PROPERTY CXX_STANDARD 11)
target_link_libraries(vectorization-report lionss pthread)

add_executable(gdb-pretty-print src/gdb-pretty-print.cpp)
set_property(TARGET gdb-pretty-print PROPERTY CXX_STANDARD 11)
target_link_libraries(gdb-pretty-print lionss pthread)

add_executable(dast-scan src/dast-scan.cpp)
set_property(TARGET dast-scan PROPERTY CXX_STANDARD 11)
target_link_libraries(dast-scan lionss pthread)

add_executable(tidy-bugprone src/tidy-bugprone.cpp)
set_property(TARGET tidy-bugprone PROPERTY CXX_STANDARD 11)
target_link_libraries(tidy-bugprone lionss pthread)

add_executable(oss-fuzz-sync src/oss-fuzz-sync.cpp)
set_property(TARGET oss-fuzz-sync PROPERTY CXX_STANDARD 11)
target_link_libraries(oss-fuzz-sync lionss pthread)

add_executable(microbench src/microbench.cpp)
set_property(TARGET microbench PROPERTY CXX_STANDARD 11)
target_link_libraries(microbench lionss pthread)

